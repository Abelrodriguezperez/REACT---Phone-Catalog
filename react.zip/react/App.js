import logo from './logo.svg';
import './App.css';
import React, {useEffect, useState} from 'react';
import { Phones } from "./component/Phones"
import { PhoneForm } from './component/PhoneForm';
import { Container } from "semantic-ui-react"

function App() {

  const [phones, setPhones] = useState([]);

  useEffect(() => {
    fetch('/phones').then(response => response.json().then(data => {
      setPhones(data.phones);
    }))
  }, [])

  return (
    <div className="App">
      
      <Container style={{marginTop: 40}}>
        <PhoneForm onNewPhone={phone => setPhones(currentPhones => [...currentPhones, phone])}/>
        <Phones phones={phones}/>
      </Container>
    </div>
  );
}

export default App;
