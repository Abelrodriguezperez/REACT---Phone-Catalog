import React, {useState} from 'react';
import { Button, Form, Input } from 'semantic-ui-react';

export const PhoneForm = ({onNewPhone}) => {
    const [id, setId] = useState("");
    const [phoneName, setPhoneName] = useState("");
    const [manufacturer, setManufacturer] = useState("");
    const [description, setDescription] = useState("");
    const [color, setColor] = useState("");
    const [price, setPrice] = useState("");
    const [imageFileName, setImageFileName] = useState("");
    const [screen, setScreen] = useState("");
    const [processor, setProcessor] = useState("");
    const [ram, setRam] = useState("");

    return (
        <Form>
            <Form.Field>
                <Input
                    placeholder="phone id"
                    value={id}
                    onChange={e => setId(e.target.value)}
                />
            </Form.Field>
            <Form.Field>
                <Input
                    placeholder="phone phoneName"
                    value={phoneName}
                    onChange={e => setPhoneName(e.target.value)}
                />
            </Form.Field>
            <Form.Field>
                <Input
                    placeholder="phone manufacturer"
                    value={manufacturer}
                    onChange={e => setManufacturer(e.target.value)}
                />
            </Form.Field>
            <Form.Field>
                <Input
                    placeholder="phone description"
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                />
            </Form.Field>
            <Form.Field>
                <Input
                    placeholder="phone color"
                    value={color}
                    onChange={e => setColor(e.target.value)}
                />
            </Form.Field>
            <Form.Field>
                <Input
                    placeholder="phone price"
                    value={price}
                    onChange={e => setPrice(e.target.value)}
                />
            </Form.Field>
            <Form.Field>
                <Input
                    placeholder="phone imageFileName"
                    value={imageFileName}
                    onChange={e => setImageFileName(e.target.value)}
                />
            </Form.Field>
            <Form.Field>
                <Input
                    placeholder="phone screen"
                    value={screen}
                    onChange={e => setScreen(e.target.value)}
                />
            </Form.Field>
            <Form.Field>
                <Input
                    placeholder="phone processor"
                    value={processor}
                    onChange={e => setProcessor(e.target.value)}
                />
            </Form.Field>
            <Form.Field>
                <Input
                    placeholder="phone ram"
                    value={ram}
                    onChange={e => setRam(e.target.value)}
                />
            </Form.Field>
            <Form.Field>
                <Button onClick={async () => {
                    const phone = {id, phoneName, manufacturer, description, color, price, imageFileName, screen, processor, ram};
                    const response = await fetch('/phones', {
                        method: 'POST',
                        headers: {
                            'Content-type': 'application/json'
                        },
                        body: JSON.stringify(phone)
                    })

                    if(response.ok){
                        console.log('it worked');
                        onNewPhone(phone);
                        setId('');
                        setPhoneName('');
                        setManufacturer('');
                        setDescription('');
                        setColor('');
                        setPrice('');
                        setImageFileName('');
                        setScreen('');
                        setProcessor('');
                        setRam('');
                        
                    }

                }}>Crear</Button>
            </Form.Field>
        </Form>
    )

}
