import React from 'react';
import { List, Header } from 'semantic-ui-react';

export const Phones = ({phones}) => {
    return(
        
        <React.Fragment><List>
          {phones.map(phone => {
              return(
                  <List.Item key={phone.id}>
                      <Header>{phone.id}</Header>
                      <Header>{phone.phoneName}</Header>
                      <Header>{phone.manufacturer}</Header>
                      <Header>{phone.description}</Header>
                      <Header>{phone.color}</Header>
                      <Header>{phone.price}</Header>
                      <Header>{phone.imageFileName}</Header>
                      <Header>{phone.screen}</Header>
                      <Header>{phone.processor}</Header>
                      <Header>{phone.ram}</Header>
                  </List.Item>
            
              )
          }

          )}  
        </List>
        

        <table className="table ">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Manufacturer</th>
                    <th>Description</th>
                    <th>Color</th>
                    <th>ImageFileName</th>
                    <th>Screen</th>
                    <th>Processor</th>
                    <th>Ram</th>
                </tr>
            </thead>
            <tbody>
                {this.state.data.map(phone=>{
                    return(
                        <tr>
                            
                            <td>{phone.id}</td>
                            <td>{phone.phoneName}</td>
                            <td>{phone.manufacturer}</td>
                            <td>{phone.description}</td>
                            <td>{phone.color}</td>
                            <td>{phone.imageFileName}</td>
                            <td>{phone.screen}</td>
                            <td>{phone.processor}</td>
                            <td>{phone.ram}</td>
                        </tr>
                    )
                })}
            </tbody>
        </table></React.Fragment>


    )
}